## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, cache = TRUE)

## ----libraries, cache=F, message=F, warning=F, include=F-----------------

library(gridExtra)
library(RxODE)
library(MASS)
library(data.table)
library(ggplot2)
library(nlmixr)
library(xpose)
library(xpose.nlmixr)
library(shinyMixR)

rm(list = ls())

## ----simulate_data, cache=T, echo=F, include=F---------------------------

mod <- RxODE({
  k10 = CL/V2
  k12 = Q/V2
  k21 = Q/V3
  d/dt(depot) =-KA*depot;
  d/dt(centr) = KA*depot - k10*centr - k12*centr + k21*peri;
  d/dt(peri)  =                        k12*centr - k21*peri;
  C2 = centr/V2;
  C3 = peri/V3;
  cp = C2 #*(1+cp.err)
})

theta <- c(TKA=1.05, TCL=0.121, TV2=1.939,
           TQ=0.282, TV3=5.65)

#The values for Cl1/F, Cl2/F, V1/F, V2/F and Ka were 121 ml/h, 282 ml/h, 1,939 ml, 5,650 ml and 1.05 h-1, respectively

omegaCor <- matrix(c(1,    0.5, 0.25, 0.1,  0,
                     0.5,  1,   0.5,  0.1,  0,
                     0.25, 0.5, 1,    0.1,  0,
                     0.1,  0.1, 0.1,  1,    0,
                     0,    0,   0,    0,    1), dimnames=list(NULL,c("eta.CL","eta.V2","eta.V3", "eta.Q", "eta.KA")), nrow=5)

iiv.sd <- c(0.25, 0.25, 0.25, 0.3, 0.3) ## SDs of model parameters

iiv <- iiv.sd %*% t(iiv.sd)
omega <- iiv * omegaCor  # covariance matrix

sigma <- diag(1)*0.1
dimnames(sigma) <- list(NULL, c("cp.err"))

set.seed(740727)

mv <- mvrnorm(40, rep(0, dim(omega)[1]), omega) # Sample from covariance matrix

#Combine population parameters with IIV
params.all <-
  data.table(
    "ID" = seq(1:40),
    "CL" = theta['TCL'] * exp(mv[, 1]),
    "V2" = theta['TV2'] * exp(mv[, 2]),
    "V3" = theta['TV3'] * exp(mv[, 3]),
    "Q"  = theta['TQ']  * exp(mv[, 4]),
    "KA" = theta['TKA'] * exp(mv[, 5]),
    "WT" = round(rnorm(40,70,15)),
    "SEX" = rbinom(n = 40, prob = 0.5, size =1)
  )
#set the doses (looping through the 4 doses)
params.all[, AMT := 1200]

params.all$CL <- params.all$CL * (params.all$WT/70)^0.75
params.all$V2 <- params.all$V2 * (1 - 0.2 * params.all$SEX)


s = lapply(1:40, function(i) {
  #selects the parameters associated with the subject to be simulated
  params <- params.all[i]
  #creates an eventTable with 7 doses every 24 hours
  ev <- eventTable()
  ev$add.dosing(
    dose = params$AMT,
    nbr.doses = 28,
    dosing.to = 1,
    dosing.interval = 24,
    rate = NULL,
    start.time = 0
  )

  smp <- c(round(runif(1, 0, 1),3),
           round(runif(1, 1, 3),3),
           round(runif(1, 3, 6), 3),
           round(runif(1, 6, 12), 3),
           round(runif(1, 18, 23.9), 3),
           round(runif(1, 168, 169),3),
           round(runif(1, 169, 171),3),
           round(runif(1, 171, 180),3),
           round(runif(1, 188, 191.9),3))

  ev$add.sampling(smp)

  x <- as.data.table(mod$run(params, ev, seed=740727))
  x$rv <- rnorm(nrow(x), 0, 0.075)
  x$DV <- round(x$cp * (1 + x$rv),1)
  x$ID <- i

  x[, names(params) := params]
})

sim <- as.data.table(do.call("rbind", s))

setnames(sim, "time", "TIME")

Dose <- expand.grid(TIME = seq(0, 7 * 24, 24), ID = params.all$ID, DV=0)
Dose <- data.table(merge(Dose, params.all, by = "ID"))
Dose[, EVID := 101]

sim[, EVID := 0]
sim[, AMT := 0]

# sim <- subset(sim, DV<10)
# sim <- subset(sim, DV>0.015)

# dilute by 50% at random
# sim <- sim[sample(nrow(sim), nrow(sim)*0.75), ]


sim <- sim[,c("ID","TIME","DV","WT","SEX","AMT","EVID")]
dat <- rbind(sim, Dose[,c("ID","TIME","DV","WT","SEX","AMT","EVID")])
setkey(dat, ID, TIME)

write.csv(dat, file="examplomycin.csv", quote = F, na = ".", row.names = F)

dat <- read.csv("examplomycin.csv", na.strings=c("."))


## ----table_figure_captions, echo=F, include=F----------------------------

## ----1cpt-nlme, cache=T, warning=F, message=F, results="hide", echo=F----


model.1cpt.cf <- function() {
  ini({
    tka <- log(1.5)
    tcl <- log(1.5)
    tv  <- log(3)
    eta.ka ~ 0.1
    eta.cl ~ 0.1
    eta.v ~ 0.1
    add.err <- 0.01
  })
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + eta.cl)
    v <- exp(tv + eta.v)
    linCmt() ~ add(add.err)
  })
}

fit.1cpt.cf.nlme <- nlmixr(model.1cpt.cf, dat, est="nlme", table=tableControl(cwres=TRUE, npde=TRUE))


## ----1cpt-nlme-results, echo=F-------------------------------------------

print(fit.1cpt.cf.nlme)


## ----1cpt-saem, cache=T, warning=F, message=F, results="hide", echo=F----

model.1cpt.ode <- function() {
  ini({
    tka <- log(1.5)
    tcl <- log(1.5)
    tv  <- log(3)
    eta.ka ~ 1
    eta.cl ~ 1
    eta.v ~ 1
    prop.err <- 0.1
  })
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + eta.cl)
    v <- exp(tv + eta.v)
    d/dt(depot) = -ka * depot
    d/dt(center) = ka * depot - cl / v * center
    cp = center / v
    cp ~ prop(prop.err)
  })
}

fit.1cpt.ode.saem <- nlmixr(model.1cpt.ode, dat, est="saem", table=tableControl(cwres=TRUE, npde=TRUE), seed=740727)


## ----1cpt-saem-results, echo=F-------------------------------------------

print(fit.1cpt.ode.saem)


## ----2cpt, cache=T, warning=F, message=F, results="hide", echo=F---------


model.2cpt.ode <- function() {
  ini({
    tka <- log(1.05)
    tcl <- log(0.121)
    tv2  <- log(1.939)
    tv3  <- log(5.65)
    tq   <- log(0.282)
    eta.ka ~ 0.1
    eta.cl ~ 0.1
    eta.v2 ~ 0.1
    eta.v3 ~ 0.1
    eta.q ~ 0.1
    add.err <- 75
  })
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + eta.cl)
    v2 <- exp(tv2 + eta.v2)
    v3 <- exp(tv3 + eta.v3)
    q  <- exp(tq + eta.q)
    d/dt(depot) = -ka * depot
    d/dt(center) = ka * depot - cl / v2 * center + q/v3 * periph - q/v2 * center
    d/dt(periph) = q/v2 * center - q/v3 * periph
    cp = center / v2
    cp ~ add(add.err)
  })
}

fit.2cpt.ode.saem <- nlmixr(model.2cpt.ode, dat, est="saem", table=tableControl(cwres=TRUE, npde=TRUE), seed=740727)


## ----2cptp, cache=T, warning=F, message=F, results="hide", echo=F--------

model.2cptp.ode <- function() {
  ini({
    tka <- log(1.05)
    tcl <- log(0.121)
    tv2  <- log(1.939)
    tv3  <- log(5.65)
    tq   <- log(0.282)
    eta.ka ~ 0.1
    eta.cl ~ 0.1
    eta.v2 ~ 0.1
    eta.v3 ~ 0.1
    eta.q ~ 0.1
    prop.err <- 0.075
  })
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + eta.cl)
    v2 <- exp(tv2 + eta.v2)
    v3 <- exp(tv3 + eta.v3)
    q  <- exp(tq + eta.q)
    d/dt(depot) = -ka * depot
    d/dt(center) = ka * depot - cl / v2 * center + q/v3 * periph - q/v2 * center
    d/dt(periph) = q/v2 * center - q/v3 * periph
    cp = center / v2
    cp ~ prop(prop.err)
  })
}

fit.2cptp.ode.saem <- nlmixr(model.2cptp.ode, dat, est="saem", table=tableControl(cwres=TRUE, npde=TRUE), seed=740727)


## ----3cpt, cache=T, warning=F, message=F, results="hide", echo=F---------

model.3cpt.ode <- function() {
  ini({
    tka <- log(1.42)
    tcl <- log(0.044)
    tv2  <- log(2)
    tv3  <- log(10)
    tv4  <- log(10)
    tq2   <- log(0.5)
    tq3   <- log(0.5)
    eta.ka ~ 0.1
    eta.cl ~ 0.1
    eta.v2 ~ 0.1
    eta.v3 ~ 0.1
    eta.v4 ~ 0.1
    eta.q2 ~ 0.1
    eta.q3 ~ 0.1
    prop.err <- 0.075
  })
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + eta.cl)
    v2 <- exp(tv2 + eta.v2)
    v3 <- exp(tv3 + eta.v3)
    v4 <- exp(tv4 + eta.v4)
    q2  <- exp(tq2 + eta.q2)
    q3  <- exp(tq3 + eta.q3)
    d/dt(depot) = -ka * depot
    d/dt(center) = ka * depot - cl / v2 * center + q2/v3 * periph1 - q2/v2 * center + q3/v4 * periph2 - q3/v2 * center
    d/dt(periph1) = q2/v2 * center - q2/v3 * periph1
    d/dt(periph2) = q3/v2 * center - q3/v4 * periph2
    cp = center / v2
    cp ~ prop(prop.err)
  })
}

fit.3cpt.ode.saem <- nlmixr(model.3cpt.ode, dat, est="saem", table=tableControl(cwres=TRUE, npde=TRUE), seed=740727)


## ----ofvtable1, echo=F---------------------------------------------------

otab <- data.frame(Model = c(1, 2, 3, 4),
                   RelativeTo = c("-", 1, 2, 3),
                   Description = c("1-cpt, additive residual error",
                             "2-cpt, additive residual error",
                             "2-cpt, proportional residual error",
                             "3-cpt, proportional residual error"),
                   OFV = c(fit.1cpt.ode.saem$value, fit.2cpt.ode.saem$value, fit.2cptp.ode.saem$value, fit.3cpt.ode.saem$value),
                   dOFV = round(c(0, fit.2cpt.ode.saem$value-fit.1cpt.ode.saem$value,
                            fit.2cptp.ode.saem$value-fit.2cpt.ode.saem$value, fit.3cpt.ode.saem$value-fit.2cptp.ode.saem$value),3),
                   AIC = c(AIC(fit.1cpt.ode.saem), AIC(fit.2cpt.ode.saem), AIC(fit.2cptp.ode.saem), AIC(fit.3cpt.ode.saem)),
                   dAIC = round(c(0, AIC(fit.2cpt.ode.saem)-AIC(fit.1cpt.ode.saem),
                            AIC(fit.2cptp.ode.saem)-AIC(fit.2cpt.ode.saem), AIC(fit.3cpt.ode.saem)-AIC(fit.2cptp.ode.saem)),3),
                   BIC = c(BIC(fit.1cpt.ode.saem), BIC(fit.2cpt.ode.saem), BIC(fit.2cptp.ode.saem), BIC(fit.3cpt.ode.saem)),
                   dBIC = round(c(0, BIC(fit.2cpt.ode.saem)-BIC(fit.1cpt.ode.saem),
                            BIC(fit.2cptp.ode.saem)-BIC(fit.2cpt.ode.saem), BIC(fit.3cpt.ode.saem)-BIC(fit.2cptp.ode.saem)),3))


## ----2cptwt, cache=T, warning=F, message=F, results="hide", echo=F-------

dat$lnWT <- log(dat$WT/70)

model.2cpt.ode.wtcl <- function() {
  ini({
    tka <- log(1.14)
    tcl <- log(0.0190)
    tv2  <- log(2.12)
    tv3  <- log(20.4)
    tq   <- log(0.383)
    wteff <- 0.35
    eta.ka ~ 1
    eta.cl ~ 1
    eta.v2 ~ 1
    eta.v3 ~ 1
    eta.q ~ 1
    prop.err <- 0.075
  })
  model({
    ka = exp(tka + eta.ka)
    cl = exp(tcl + wteff*lnWT + eta.cl)
    v2 = exp(tv2 + eta.v2)
    v3 = exp(tv3 + eta.v3)
    q  = exp(tq + eta.q)
    d/dt(depot) = -ka * depot
    d/dt(center) = ka * depot - cl / v2 * center + q/v3 * periph - q/v2 * center
    d/dt(periph) = q/v2 * center - q/v3 * periph
    cp = center / v2
    cp ~ prop(prop.err)
  })
}

fit.2cpt.ode.wtcl.saem <- nlmixr(model.2cpt.ode.wtcl, dat, est="saem", table=tableControl(cwres=TRUE, npde=TRUE))


## ----2cptsex, cache=T, warning=F, message=F, results="hide", echo=F------

model.2cpt.ode.sexv2 <- function() {
  ini({
    tka <- log(1.14)
    tcl <- log(0.0190)
    tv2  <- log(2.12)
    tv3  <- log(20.4)
    tq   <- log(0.383)
    sexeff <- -0.2
    eta.ka ~ 1
    eta.cl ~ 1
    eta.v2 ~ 1
    eta.v3 ~ 1
    eta.q ~ 1
    prop.err <- 0.075
  })
  model({
    ka = exp(tka + eta.ka)
    cl = exp(tcl + eta.cl)
    v2 = exp(tv2 + sexeff*(SEX) + eta.v2)
    v3 = exp(tv3 + eta.v3)
    q  = exp(tq + eta.q)
    d/dt(depot) = -ka * depot
    d/dt(center) = ka * depot - cl / v2 * center + q/v3 * periph - q/v2 * center
    d/dt(periph) = q/v2 * center - q/v3 * periph
    cp = center / v2
    cp ~ prop(prop.err)
  })
}

fit.2cpt.ode.sexv2.saem <- nlmixr(model.2cpt.ode.sexv2, dat, est="saem", table=tableControl(cwres=TRUE, npde=TRUE))


## ----2cptwtsex, cache=T, warning=F, message=F, results="hide", echo=F----

model.2cpt.ode.wtcl.sexv2 <- function() {
  ini({
    tka <- log(1.14)
    tcl <- log(0.0190)
    tv2  <- log(2.12)
    tv3  <- log(20.4)
    tq   <- log(0.383)
    wteff  <- 0.35
    sexeff <- -0.2
    eta.ka ~ 1
    eta.cl ~ 1
    eta.v2 ~ 1
    eta.v3 ~ 1
    eta.q ~ 1
    prop.err <- 0.075
  })
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + wteff*lnWT + eta.cl)
    v2 <- exp(tv2 + sexeff*(SEX) + eta.v2)
    v3 <- exp(tv3 + eta.v3)
    q  <- exp(tq + eta.q)
    d/dt(depot) = -ka * depot
    d/dt(center) = ka * depot - cl / v2 * center + q/v3 * periph - q/v2 * center
    d/dt(periph) = q/v2 * center - q/v3 * periph
    cp = center / v2
    cp ~ prop(prop.err)
  })
}

## broke.
fit.2cpt.ode.wtcl.sexv2.saem <- nlmixr(model.2cpt.ode.wtcl.sexv2, dat, est="saem", table=tableControl(cwres=TRUE, npde=TRUE))


## ----2cptwtsex2, cache=T, warning=F, message=F, results="hide", echo=F----

model.2cpt.ode.wtcl.sexv2 <- function() {
  ini({
    tka <- log(1.14)
    tcl <- log(0.0190)
    tv2  <- log(2.12)
    tv3  <- log(20.4)
    tq   <- log(0.383)
    wteff  <- 0.35
    sexeff <- -0.2
    eta.ka ~ 1
    eta.cl ~ 1
    eta.v2 ~ 1
    eta.v3 ~ 1
    eta.q ~ 1
    prop.err <- 0.075
  })
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + wteff*lnWT + eta.cl)
    v2 <- exp(tv2 + sexeff*(SEX) + eta.v2)
    v3 <- exp(tv3 + eta.v3)
    q  <- exp(tq + eta.q)
    d/dt(depot) = -ka * depot
    d/dt(center) = ka * depot - cl / v2 * center + q/v3 * periph - q/v2 * center
    d/dt(periph) = q/v2 * center - q/v3 * periph
    cp = center / v2
    cp ~ prop(prop.err)
  })
}

fit.2cpt.ode.wtcl.sexv2.saem <- nlmixr(model.2cpt.ode.wtcl.sexv2, dat, est="saem", table=tableControl(cwres=TRUE, npde=TRUE))


## ----2cptwtsex_foce, cache=T, warning=F, message=F, results="hide", echo=F----

model.2cpt.ode.wtcl.sexv2.foce <- function() {
  ini({
    tka <- log(1.14)
    tcl <- log(0.0190)
    tv2  <- log(2.12)
    tv3  <- log(20.4)
    tq   <- log(0.383)
    wteff  <- 0.35
    sexeff <- -0.2
    eta.ka ~ 0.3
    eta.cl ~ 0.3
    eta.v2 ~ 0.3
    prop.err <- 0.075
  })
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + wteff*lnWT + eta.cl)
    v2 <- exp(tv2 + sexeff*(SEX) + eta.v2)
    v3 <- exp(tv3)
    q  <- exp(tq)
    linCmt() ~ prop(prop.err)
  })
}

fit.2cpt.ode.wtcl.sexv2.foce <- nlmixr(model.2cpt.ode.wtcl.sexv2.foce, dat, est="focei", table=tableControl(cwres=TRUE, npde=TRUE))

model.2cpt.ode.wtcl.sexv2.foce2 <- function() {
  ini({
    tka <- log(1.14)
    tcl <- log(0.0190)
    tv2  <- log(2.12)
    tv3  <- log(20.4)
    tq   <- log(0.383)
    wteff  <- 0.35
    sexeff <- -0.2
    eta.ka ~ 0.3
    eta.cl ~ 0.3
    eta.v2 ~ 0.3
    eta.v3 ~ 0.3
    eta.q ~ 0.3
    prop.err <- 0.075
  })
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + wteff*lnWT + eta.cl)
    v2 <- exp(tv2 + sexeff*(SEX) + eta.v2)
    v3 <- exp(tv3 + eta.v3)
    q  <- exp(tq + eta.q)
    linCmt() ~ prop(prop.err)
  })
}

fit.2cpt.ode.wtcl.sexv2.foce2 <- nlmixr(model.2cpt.ode.wtcl.sexv2.foce2, dat, est="focei", table=tableControl(cwres=TRUE, npde=TRUE))


## ----2cptwtsex_corr, cache=T, warning=F, message=F, results="hide", echo=F----

model.2cpt.ode.wtcl.sexv2.cor <- function() {
  ini({
    tka <- log(1.14)
    tcl <- log(0.0190)
    tv2  <- log(2.12)
    tv3  <- log(20.4)
    tq   <- log(0.383)
    wteff  <- 0.35
    sexeff <- -0.2
    eta.ka ~ 1
    eta.cl + eta.v2 ~ c(1, 0.5, 1)
    eta.v3 ~ 1
    eta.q ~ 1
    prop.err <- 0.075
  })
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + wteff*lnWT + eta.cl)
    v2 <- exp(tv2 + sexeff*(SEX) + eta.v2)
    v3 <- exp(tv3 + eta.v3)
    q  <- exp(tq + eta.q)
    d/dt(depot) = -ka * depot
    d/dt(center) = ka * depot - cl / v2 * center + q/v3 * periph - q/v2 * center
    d/dt(periph) = q/v2 * center - q/v3 * periph
    cp = center / v2
    cp ~ prop(prop.err)
  })
}

fit.2cpt.ode.wtcl.sexv2.cor.saem <- nlmixr(model.2cpt.ode.wtcl.sexv2.cor, dat, est="saem", table=tableControl(cwres=TRUE, npde=TRUE))


## ----2cptwtsex_results---------------------------------------------------

print(fit.2cpt.ode.wtcl.sexv2.saem)


## ----ofvtable2, echo=F---------------------------------------------------

otab <- data.frame(Model = c(1, 2, 3, 4, 5, 6, 7),
                   RelativeTo = c("-", 1, 2, 3, 3, 3, 5),
                   Description = c("1-cpt, add residual error",
                             "2-cpt, add residual error",
                             "2-cpt, prop residual error (base)",
                             "3-cpt, prop residual error",
                             "Base with WT-CL",
                             "Base with SEX-V2",
                             "Base with WT-CL, SEX-V2 (final)"),
                   OFV = c(fit.1cpt.ode.saem$value, fit.2cpt.ode.saem$value, fit.2cptp.ode.saem$value, fit.3cpt.ode.saem$value,
                           fit.2cpt.ode.wtcl.saem$value, fit.2cpt.ode.sexv2.saem$value, fit.2cpt.ode.wtcl.sexv2.saem$value),
                   dOFV = round(c(0,
                                  fit.2cpt.ode.saem$value-fit.1cpt.ode.saem$value,
                                  fit.2cptp.ode.saem$value-fit.2cpt.ode.saem$value,
                                  fit.3cpt.ode.saem$value-fit.2cptp.ode.saem$value,
                                  fit.2cpt.ode.wtcl.saem$value-fit.2cptp.ode.saem$value,
                                  fit.2cpt.ode.sexv2.saem$value-fit.2cptp.ode.saem$value,
                                  fit.2cpt.ode.wtcl.sexv2.saem$value-fit.2cpt.ode.wtcl.saem$value),3),
                   AIC = c(AIC(fit.1cpt.ode.saem), AIC(fit.2cpt.ode.saem), AIC(fit.2cptp.ode.saem), AIC(fit.3cpt.ode.saem),
                           AIC(fit.2cpt.ode.wtcl.saem), AIC(fit.2cpt.ode.sexv2.saem), AIC(fit.2cpt.ode.wtcl.sexv2.saem)),
                   dAIC = round(c(0,
                                  AIC(fit.2cpt.ode.saem)-AIC(fit.1cpt.ode.saem),
                                  AIC(fit.2cptp.ode.saem)-AIC(fit.2cpt.ode.saem),
                                  AIC(fit.3cpt.ode.saem)-AIC(fit.2cptp.ode.saem),
                                  AIC(fit.2cpt.ode.wtcl.saem)-AIC(fit.2cptp.ode.saem),
                                  AIC(fit.2cpt.ode.sexv2.saem)-AIC(fit.2cptp.ode.saem),
                                  AIC(fit.2cpt.ode.wtcl.sexv2.saem)-AIC(fit.2cpt.ode.wtcl.saem)),3),
                   BIC = c(BIC(fit.1cpt.ode.saem), BIC(fit.2cpt.ode.saem), BIC(fit.2cptp.ode.saem), BIC(fit.3cpt.ode.saem),
                           BIC(fit.2cpt.ode.wtcl.saem), BIC(fit.2cpt.ode.sexv2.saem), BIC(fit.2cpt.ode.wtcl.sexv2.saem)),
                   dBIC = round(c(0,
                                  BIC(fit.2cpt.ode.saem)-BIC(fit.1cpt.ode.saem),
                                  BIC(fit.2cptp.ode.saem)-BIC(fit.2cpt.ode.saem),
                                  BIC(fit.3cpt.ode.saem)-BIC(fit.2cptp.ode.saem),
                                  BIC(fit.2cpt.ode.wtcl.saem)-BIC(fit.2cptp.ode.saem),
                                  BIC(fit.2cpt.ode.sexv2.saem)-BIC(fit.2cptp.ode.saem),
                                  BIC(fit.2cpt.ode.wtcl.sexv2.saem)-BIC(fit.2cpt.ode.wtcl.saem)),3))


## ----tab1, fig.cap=tab.1_cap, include=F, echo=F--------------------------
##

## ----tab2, fig.cap=tab.2_cap, include=F, echo=F--------------------------
##

## ----ofvtable2out, fig.cap=tab.3_cap, echo=F-----------------------------

knitr::kable(
  otab, longtable = TRUE, booktabs = TRUE)


## ----plotdata, fig.cap=fig.1_cap, fig.width=8, fig.height=5, echo=F------

dat$Day <- "Day 1"
dat$Day[dat$TIME>167] <- "Day 8"

ggplot(subset(data.frame(dat), EVID==0), aes(TIME, DV)) + geom_point(col="#1F4E79") +
  geom_line(aes(group=ID), col="#1F4E79") +
  scale_x_continuous("Time (h)") +
  scale_y_log10("Concentration (mg/L)") +
  facet_wrap(~ Day, scales="free_x")


## ----fig2, fig.cap=fig.2_cap, include=F, echo=F--------------------------
##

## ----1cpt-xpose, fig.cap=fig.3_cap, fig.width=8, fig.height=8, warning=F, message=F, echo=F----

xp.1cpt.ode.saem <- xpose_data_nlmixr(fit.1cpt.ode.saem, xp_theme = theme_xp_nlmixr())

xp1 <- dv_vs_pred(xp.1cpt.ode.saem, title = "DV vs PRED",
                  subtitle = NULL, caption = NULL) +
  coord_cartesian(ylim=c(0,1000), xlim=c(0,1000)) +
  scale_x_continuous("Population predictions") +
  scale_y_continuous("Observed concentrations")

xp2 <- dv_vs_ipred(xp.1cpt.ode.saem, title = "DV vs IPRED",
                   subtitle = NULL, caption = NULL) +
  coord_cartesian(ylim=c(0,1000), xlim=c(0,1000))+
  scale_x_continuous("Individual predictions") +
  scale_y_continuous("Observed concentrations")

xp3 <- res_vs_idv(xp.1cpt.ode.saem, res = "CWRES", title = "CWRES vs time",
                  subtitle = NULL, caption = NULL) +
  coord_cartesian(ylim=c(-3.5,3.5)) +
  scale_x_continuous("Time (h)") +
  scale_y_continuous("Conditional weighted residuals")

xp4 <- res_vs_pred(xp.1cpt.ode.saem, res = "CWRES", title = "CWRES vs PRED",
                   subtitle = NULL, caption = NULL)+
  coord_cartesian(ylim=c(-3.5,3.5))+
  scale_x_continuous("Population predictions") +
  scale_y_continuous("Conditional weighted residuals")

grid.arrange(xp1, xp2, xp3, xp4, nrow=2)


## ----1cpt-vpc, fig.cap=fig.4_cap, fig.width=8, fig.height=5, warning=F, message=F, echo=F----

bins <- c(0, 3, 12, 24, 168, 171, 180, 192)
vpc.1cpt <- nlmixr::vpc(fit.1cpt.ode.saem, nsim=400,show=list(obs_dv=T),
                        bins=bins);
vpc.1cpt$gg +
    scale_x_continuous("Time (h)") +
    scale_y_continuous("Concentration")


## ----fig5, fig.cap=fig.5_cap, include=F, echo=F--------------------------
##

## ----2cptwtsex-xpose, fig.cap=fig.6_cap, fig.width=8, fig.height=8, warning=F, message=F, echo=F----

xp.2cpt.wtcl.sexv2.ode.saem <- xpose_data_nlmixr(fit.2cpt.ode.wtcl.sexv2.saem,
                                                 xp_theme = theme_xp_nlmixr())

xp1 <- dv_vs_pred(xp.2cpt.wtcl.sexv2.ode.saem, title = "DV vs PRED",
                  subtitle = NULL, caption = NULL) +
  coord_cartesian(ylim=c(0,1000), xlim=c(0,1000))+
  scale_y_continuous("Observed concentrations") +
  scale_x_continuous("Population predictions")

xp2 <- dv_vs_ipred(xp.2cpt.wtcl.sexv2.ode.saem, title = "DV vs IPRED",
                   subtitle = NULL, caption = NULL) +
  coord_cartesian(ylim=c(0,1000), xlim=c(0,1000))+
  scale_y_continuous("Observed concentrations") +
  scale_x_continuous("Individual predictions")

xp3 <- res_vs_idv(xp.2cpt.wtcl.sexv2.ode.saem, res = "CWRES", title = "CWRES vs time",
                  subtitle = NULL, caption = NULL) +
  coord_cartesian(ylim=c(-3.5,3.5))+
  scale_y_continuous("Conditional weighted residuals") +
  scale_x_continuous("Time (h)")

xp4 <- res_vs_pred(xp.2cpt.wtcl.sexv2.ode.saem, res = "CWRES", title = "CWRES vs PRED",
                   subtitle = NULL, caption = NULL)+
  coord_cartesian(ylim=c(-3.5,3.5))+
  scale_y_continuous("Conditional weighted residuals") +
  scale_x_continuous("Population predictions")

pdf("fig1.pdf",width=8,height=8)
grid.arrange(xp1, xp2, xp3, xp4, nrow=2)
dev.off()


## ----2cptwtsex-vpc, fig.cap=fig.7_cap, fig.width=8, fig.height=5, warning=F, message=F, echo=F----

bins <- c(0, 3, 12, 24, 168, 171, 180, 192)
vpc.2cpt <- nlmixr::vpc(fit.2cpt.ode.wtcl.sexv2.saem, nsim=700,show=list(obs_dv=T),
                   bins=bins)

pdf("fig2.pdf",width=8,height=8)
vpc.2cpt$gg +
  scale_x_continuous("Time (h)") +
    scale_y_continuous("Concentration")
dev.off()


## ----screenshot, fig.cap=fig.8_cap, include=F, echo=F--------------------
##

## ----tabs1, fig.cap=tab.s1_cap, include=F, echo=F------------------------
##

## ----2cpta_results, echo=F-----------------------------------------------

print(fit.2cpt.ode.saem)


## ----2cptp_results, echo=F-----------------------------------------------

print(fit.2cptp.ode.saem)


## ----3cptp_results, echo=F-----------------------------------------------

print(fit.3cpt.ode.saem)


## ----2cpt_wtcl_results, echo=F-------------------------------------------

print(fit.2cpt.ode.wtcl.saem)


## ----2cpt_sexv2_results, echo=F------------------------------------------

print(fit.2cpt.ode.sexv2.saem)


## ----tabs2, fig.cap=tab.s2_cap, include=F, echo=F------------------------
##

## ----tabs3, fig.cap=tab.s3_cap, include=F, echo=F------------------------
##

## ----tabs4, fig.cap=tab.s4_cap, include=F, echo=F------------------------
##

## ----tabs5, fig.cap=tab.s5_cap, include=F, echo=F------------------------
##


## RxODE simulation

ev <- eventTable(amount.units="mg", time.units="hours") %>%
    add.dosing(dose=600, nbr.doses=10, dosing.interval=24) %>%
    add.dosing(dose=2000, nbr.doses=5,
               start.time=240,dosing.interval=48) %>%
    add.sampling(0:480);

sim.2cpt <- simulate(fit.2cpt.ode.saem, events=ev, nSub=500)

sim.2cpt.unc <- simulate(fit.1cpt.ode.saem,
                         events=ev, nSub=500, nStud=100)

pdf("fig3.pdf",width=8,height=8)
plot(sim.2cpt.unc)
dev.off()


## Remove large objects to reduce file size
rm(vpc.1cpt)
rm(vpc.2cpt)
rm(sim.2cpt.unc)
rm(sim.2cpt)

## Save image and zip.
save.image("win-tutorial.Rdata")
zip("SupplementalMaterial.zip", c("win-tutorial.Rdata",
                                  "Pharmacometric_model_development_with_nlmixr_dr0.1_word.R",
                                  "examplomycin.csv"))
